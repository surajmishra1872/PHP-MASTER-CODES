

<form action="formdata.php" method="post">
<input type="text" placeholder="enter name" name="name"/><br/>
<input type="submit" value="save" name="submit"/><br/>
</form>

