<?php
$conn=mysqli_connect("localhost","root","","php_crud") or die("Connection Failed");
?>