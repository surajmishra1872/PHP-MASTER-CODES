<?php include 'header.php'?>
    <div id="logindiv">
        <h1><u>User</u> Login</h1>
        <form>

            <input type="email" placeholder="Enter Your Email...."/><br/>
            <input type="password" placeholder="Enter Your Password...."/><br>
            <input type="submit" value="Login" name="login"/>

        </form>
        </div>
