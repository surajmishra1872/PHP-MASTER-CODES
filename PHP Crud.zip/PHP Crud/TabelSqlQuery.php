CREATE TABLE student(
  id int not null AUTO_INCREMENT,
  email varchar(250),
  mobile varchar(30),
  address varchar(500),
  gender varchar(40),
  message varchar(500),
  password varchar(20),
  primary key(id)
);

